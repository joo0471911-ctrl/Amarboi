"""
সব সাউন্ড (৪১৬টি) একবারে mp3 বানানোর স্ক্রিপ্ট।
শুধু একবার ইন্টারনেট লাগবে। তৈরি হলে audio/ ফোল্ডারের ফাইলগুলো আর নেট ছাড়াই বাজবে।

চালানোর নিয়ম (কম্পিউটারে, এই ফোল্ডারের ভেতর থেকে):
    pip install edge-tts
    python tools/make_audio.py

আগে থেকে তৈরি ফাইল স্কিপ করে, তাই মাঝপথে থামলে আবার চালালে বাকিটা হবে।
"""
import asyncio, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "audio")
os.makedirs(OUT, exist_ok=True)
items = json.load(open(os.path.join(HERE, "sounds_list.json"), encoding="utf-8"))

# ভয়েস বদলাতে চাইলে এখানে নাম বদলান (edge-tts --list-voices দেখুন)
VOICES = {
    "bn-BD": "bn-BD-NabanitaNeural",
    "ar-SA": "ar-SA-ZariyahNeural",
    "en-US": "en-US-AnaNeural",
}
RATE = {"bn-BD": "-10%", "ar-SA": "-15%", "en-US": "-10%"}

async def main():
    try:
        import edge_tts
    except ImportError:
        sys.exit("আগে চালান: pip install edge-tts")
    done = failed = 0
    sem = asyncio.Semaphore(4)

    async def one(it):
        nonlocal done, failed
        path = os.path.join(OUT, it["id"] + ".mp3")
        if os.path.exists(path) and os.path.getsize(path) > 500:
            return
        async with sem:
            for attempt in range(3):
                try:
                    await edge_tts.Communicate(
                        it["text"], VOICES[it["lang"]], rate=RATE[it["lang"]]
                    ).save(path)
                    done += 1
                    print("ok  ", it["id"])
                    return
                except Exception as e:
                    await asyncio.sleep(1.5)
            failed += 1
            print("FAIL", it["id"])

    await asyncio.gather(*(one(i) for i in items))
    print(f"\nতৈরি: {done}, ব্যর্থ: {failed}. ব্যর্থ থাকলে আবার চালান।")

asyncio.run(main())
