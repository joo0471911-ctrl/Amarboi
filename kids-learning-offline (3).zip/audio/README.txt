এই ফোল্ডারে mp3 ফাইল থাকবে (যেমন soro-1.mp3, num-5.mp3)।
tools/make_audio.py চালালে এখানে ফাইলগুলো তৈরি হবে।
